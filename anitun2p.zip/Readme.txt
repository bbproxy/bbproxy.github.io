AniTuner 2 Portable - Readme
----------------------------

Description
-----------

AniTuner is a free software to create, edit and convert animated cursors (.ani). Animated cursor files contain an animated mouse pointer for Windows.

Make animated cursors from animated GIF, AVI clips, bitmap strips, or by importing existing image files (BMP, JPEG, PNG, GIF, PSD, ICO, CUR) as cursor frames.

Create animated GIF, AVI clips, Adobe Flash movies, bitmap strips from animated cursors or any other image.

Resize and edit frames, set frame duration, change color depth, create 32-bit XP and Vista cursors with partial transparency (alpha channel).

Use animated cursors not only to customize the appearance of Windows but also to insert animations in your web pages, blogs, instant messaging applications, e-mails, presentations, movies or even programs...


Requires Microsoft Windows(R) 98, ME, 2000 SP4, XP, 2003 Server, Vista or higher.

AniTuner is copyright � G.D.G Software 2006-2009. All Rights Reserved.


Usage
-----

Just unpack the archive to a folder. No installation is required, no changes are made to your system files or registry.

Note: AniTuner saves its settings in a preference file named "AniTunerPref.xml" in the same folder as AniTuner.exe, and profiles in a subfolder named "Profiles".
These folders should not be write-protected, otherwise AniTuner will store its settings in your Windows Application Data folder (see Uninstall below for further information).

Execute AniTuner.exe to start AniTuner and follow the instructions.

At any time, click Help or press F1 to open the documentation.


Documentation
-------------

See the HTML Help file "AniTuner.chm". It is also available in HTML format online at

http://www.gdgsoft.com/anituner/help


Homepage
--------

http://www.gdgsoft.com/anituner


License
-------

AniTuner may be distributed and used freely, even for commercial use.
Although AniTuner has been extensively tested, it comes with ABSOLUTELY NO WARRANTY.
Refer to the AniTuner License Agreement in AniTuner.chm for details.

Please report all problems or suggestions. Thanks.


Uninstall
---------

Remove the folder that contains AniTuner.

If this folder was write-protected, AniTuner may have stored its preferences in a subfolder named "AniTuner" which is located in the Windows Application Data folder.
Generally:
On XP/2000/2003: C:\Documents and Settings\[User Name]\Application Data\AniTuner
On Vista/2008: C:\Users\[User Name]\appdata\roaming\AniTuner
On W9x/Me: C:\WINDOWS\Application Data\AniTuner

You can safely remove the files inside that folder if you do not want to keep your preferences for AniTuner.


Change History
--------------

Version 2.0: major release

- New interface
- Now fully compatible with Windows Vista
- New portable edition that does not require any installation nor leave traces on the user computer
- New: import bitmap strips (vertical or horizontal) as animated cursors
- New: reverse the order of a set of frames or all frames
- New: frame operations like horizontal flip, vertical flip, left/right rotation, progressive rotation
- New: merge a transparent image with all selected frames (so you can add a mouse pointer in some clicks to your cursor)
- New: set duration of a set of frames or all frames
- New: remove a set of frames
- Fixed memory leaks and new memory manager
- With some cursors, a wrong duration in seconds was displayed
- Improved GIF export
- Improved image import & transparency support when resizing
- Improved Flash SWF export
- Now always exports 32-bit bitmap strips. Thus alpha channels are kept for 32-bit cursors
- Improved disassembly import and export (and fixed a bug in frame count)
- Improved cursor resizing methods
- All conversion routines now keep existing color palettes
- Cursor properties are now correctly updated when you are working on frames
- New and updated samples
- Improved help file


Support
-------

You can get the latest version of AniTuner as well as other G.D.G. Software products by going to our website at:
http://www.gdgsoft.com

You can also go to the AniTuner forum to post your queries or read contributions from other users:
http://www.gdgsoft.com/forum

If you have questions, bugs or feedback regarding AniTuner to report, you can contact us by e-mail:
aniTuner@gdgsoft.com

or at http://www.gdgsoft.com/contact

Please indicate your full name, a valid E-Mail address, the version of AniTuner you are using (and your computer configuration if this is a bug report).


Notes
-----

1) Do not remove the preference file "AniTunerpref.xml" from the folder where AniTuner.exe is located if you want it to save its settings in that folder.

2) AniTuner.exe was compressed with UPX 3.03 available at http://upx.sourceforge.net/ to make the distribution smaller.